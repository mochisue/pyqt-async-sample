# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['PyQt6>=6.1.1,<7.0.0',
 'objgraph>=3.5.0,<4.0.0',
 'progress>=1.6,<2.0',
 'tqdm>=4.62.2,<5.0.0']

entry_points = \
{'console_scripts': ['pyqtasync_gui = src.sample:main']}

setup_kwargs = {
    'name': 'src',
    'version': '0.1.0',
    'description': 'Learn how to create a simple asynchronous PyQt GUI Application',
    'long_description': None,
    'author': 'mochisue',
    'author_email': 'motoki32925@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
